<ul id='subui'>
	<li><a href="javascript:void(0);" onclick="<?php echo pluginMenu('action=index'); ?>">Meta Tag Generator</a></li>
</ul>