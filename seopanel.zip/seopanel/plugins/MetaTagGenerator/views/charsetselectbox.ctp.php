<select name="charset">
	<option value=""></option>
	<option>GB2312</option>
	<option>US-ASCII</option>
	<option>ISO-8859-1</option>
	<option>ISO-8859-2</option>
	<option>ISO-8859-3</option>
	<option>ISO-8859-4</option>
	<option>ISO-8859-5</option>
	<option>ISO-8859-6</option>
	<option>ISO-8859-7</option>
	<option>ISO-8859-8</option>
	<option>ISO-8859-9</option>
	<option>ISO-2022-JP</option>
	<option>ISO-2022-JP-2</option>
	<option>ISO-2022-KR</option>
	<option>SHIFT_JIS</option>
	<option>EUC-KR</option>
	<option>BIG5</option>
	<option>KOI8-R</option>
	<option>KSC_5601</option>
	<option>HZ-GB-2312</option>
	<option>JIS_X0208</option>
	<option>UTF-8</option>
	<option>other</option>
</select>
