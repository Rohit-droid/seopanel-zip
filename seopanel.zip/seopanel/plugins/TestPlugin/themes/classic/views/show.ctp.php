<img src="<?php echo PLUGIN_IMGPATH?>/<?php echo $img?>">
