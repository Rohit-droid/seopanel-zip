# SEO Diary

SEO Diary plugin used to store all information done about a website in diary format