<?php echo  showSectionHead($spTextPanel['About Us']); ?>
<table width="60%" cellspacing="0" cellpadding="0" class="summary">
	<tr><td class="topheader" colspan="2"><?php echo $spText['label']['Developers']?></td></tr>
	<tr>
		<td class="content" style="border-left: none;width: 30%">PHP,MYSQL,AJAX,HTML</td>					
		<td class="contentmid" style="text-align: left;padding-left: 10px">Geo Varghese, <a href="http://www.seopanel.in/" target="_blank">www.seopanel.in</a></td>
	</tr>
	<tr>
		<td colspan="2" class="content" style="border-left: none;text-align: center;">
			<a href="<?php echo SP_CONTACT_LINK?>" target="_blank"><b><?php echo $pluginText['integratenewscript']?></b></a>
		</td>
	</tr>
</table>
