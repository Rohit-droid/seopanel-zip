<tr>
	<td colspan="<?php echo $colspan + 2;?>"><b><?php echo $msg?></b></td>
</tr>
