<?php echo $newsContent;?>
