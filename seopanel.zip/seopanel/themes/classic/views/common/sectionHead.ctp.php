<div class="SectionHeader">
	<h3>
		<?php echo $sectionHead?> 
	</h3>
</div>
