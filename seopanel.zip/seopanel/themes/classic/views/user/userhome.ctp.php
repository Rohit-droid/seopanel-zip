<div class="col-sm-12" style="padding: 0%;margin: 0% 0%;"> 
    <div id="content" style="margin: 0 2.5%;">
    	<script type="text/javascript">
           	scriptDoLoad('archive.php', 'content', '<?php echo getRequestParamStr(); ?>');
    	</script>
    </div>
</div>