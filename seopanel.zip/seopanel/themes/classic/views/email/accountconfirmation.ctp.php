<?php echo $spText['common']['Hello']?> <?php echo $name?>,<br><br>

<?php echo $spTextRegister['user_confirm_mail_cont_1']?> <?php echo SP_COMPANY_NAME?>.<br><br>

<?php echo $spTextRegister['user_confirm_mail_cont_2']?>:<br><br>

<a href="<?php echo $confirmLink?>"><?php echo $confirmLink?></a><br><br>

<?php echo $spText['common']['Thank you']; ?>,<br>
<?php echo SP_COMPANY_NAME?><br>
<a href="<?php echo SP_WEBPATH?>"><?php echo SP_WEBPATH?></a>